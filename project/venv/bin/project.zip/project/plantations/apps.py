from django.apps import AppConfig


class PlantationsConfig(AppConfig):
    name = 'plantations'